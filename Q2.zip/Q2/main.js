let stringCont = document.getElementById("str-var");
let intCont = document.getElementById("int-var");
let sumFuncAns = document.getElementById("sum-func-answer");
let if_elseAns = document.getElementById("if-else-header-answer");


let stringVar = "Sreeja";
stringCont.innerHTML = stringVar;
let integerVar = 30;
intCont.innerHTML = integerVar;

let sumFunc = (number1, number2) => {
  return number1 + number2;
};


sumFuncAns.innerHTML = sumFunc(1,7);


let age = 30;
if (age >= 18) {
  if_elseAns.innerHTML = "Yes";
} else {
  if_elseAns.innerHTML = "No";
}


for (let a = 1; a < 11; a++) {
  document.write(a * 5+ "<br>");
}